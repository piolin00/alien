import React from 'react';
import SideBarMenu from './SideBarMenu';

const LeftBar = () => (
        <SideBarMenu />
);

export default LeftBar;